NILL FOREX HUB — VERSION 3
Upload index.html to the root of your GitHub Pages repository.

Live data:
- Crypto: Binance public REST API
- FX reference rates: Frankfurter API
- Charts: Chart.js

No API key is required for these public endpoints. GitHub Pages is static hosting, so never put private API keys in this file.
